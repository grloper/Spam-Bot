﻿
namespace Spam_Bot_by_Ofek_Ventura
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.PanelAfter = new System.Windows.Forms.Panel();
            this.lblTimeReamining = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.tbTEXT = new System.Windows.Forms.TextBox();
            this.tbMS = new System.Windows.Forms.TextBox();
            this.lblMs = new System.Windows.Forms.Label();
            this.lblText = new System.Windows.Forms.Label();
            this.lblUpdate = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.PanelBefore = new System.Windows.Forms.Panel();
            this.btnFirstStart = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.tmrSpam = new System.Windows.Forms.Timer(this.components);
            this.tmrUpdate = new System.Windows.Forms.Timer(this.components);
            this.tmrCountdown = new System.Windows.Forms.Timer(this.components);
            this.PanelAfter.SuspendLayout();
            this.PanelBefore.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelAfter
            // 
            this.PanelAfter.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PanelAfter.BackgroundImage")));
            this.PanelAfter.Controls.Add(this.lblTimeReamining);
            this.PanelAfter.Controls.Add(this.btnBack);
            this.PanelAfter.Controls.Add(this.tbTEXT);
            this.PanelAfter.Controls.Add(this.tbMS);
            this.PanelAfter.Controls.Add(this.lblMs);
            this.PanelAfter.Controls.Add(this.lblText);
            this.PanelAfter.Controls.Add(this.lblUpdate);
            this.PanelAfter.Controls.Add(this.btnStart);
            this.PanelAfter.Controls.Add(this.btnStop);
            this.PanelAfter.Location = new System.Drawing.Point(3, 3);
            this.PanelAfter.Name = "PanelAfter";
            this.PanelAfter.Size = new System.Drawing.Size(349, 236);
            this.PanelAfter.TabIndex = 1;
            // 
            // lblTimeReamining
            // 
            this.lblTimeReamining.AutoSize = true;
            this.lblTimeReamining.BackColor = System.Drawing.Color.Transparent;
            this.lblTimeReamining.Font = new System.Drawing.Font("Footlight MT Light", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTimeReamining.ForeColor = System.Drawing.Color.White;
            this.lblTimeReamining.Location = new System.Drawing.Point(6, 28);
            this.lblTimeReamining.Name = "lblTimeReamining";
            this.lblTimeReamining.Size = new System.Drawing.Size(148, 19);
            this.lblTimeReamining.TabIndex = 8;
            this.lblTimeReamining.Text = "Time Reamining:";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.Maroon;
            this.btnBack.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(215, 186);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(124, 29);
            this.btnBack.TabIndex = 7;
            this.btnBack.Text = "Return To Menu";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // tbTEXT
            // 
            this.tbTEXT.Location = new System.Drawing.Point(28, 107);
            this.tbTEXT.Name = "tbTEXT";
            this.tbTEXT.Size = new System.Drawing.Size(165, 27);
            this.tbTEXT.TabIndex = 6;
            // 
            // tbMS
            // 
            this.tbMS.Location = new System.Drawing.Point(28, 177);
            this.tbMS.Name = "tbMS";
            this.tbMS.Size = new System.Drawing.Size(165, 27);
            this.tbMS.TabIndex = 5;
            this.tbMS.TextChanged += new System.EventHandler(this.tbMS_TextChanged);
            // 
            // lblMs
            // 
            this.lblMs.AutoSize = true;
            this.lblMs.BackColor = System.Drawing.Color.Transparent;
            this.lblMs.ForeColor = System.Drawing.Color.White;
            this.lblMs.Location = new System.Drawing.Point(28, 153);
            this.lblMs.Name = "lblMs";
            this.lblMs.Size = new System.Drawing.Size(134, 20);
            this.lblMs.TabIndex = 4;
            this.lblMs.Text = "Enter The ms Value";
            // 
            // lblText
            // 
            this.lblText.AutoSize = true;
            this.lblText.BackColor = System.Drawing.Color.Transparent;
            this.lblText.ForeColor = System.Drawing.Color.White;
            this.lblText.Location = new System.Drawing.Point(28, 78);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(100, 20);
            this.lblText.TabIndex = 3;
            this.lblText.Text = "Enter The text";
            // 
            // lblUpdate
            // 
            this.lblUpdate.AutoSize = true;
            this.lblUpdate.BackColor = System.Drawing.Color.Transparent;
            this.lblUpdate.Font = new System.Drawing.Font("Footlight MT Light", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblUpdate.ForeColor = System.Drawing.Color.White;
            this.lblUpdate.Location = new System.Drawing.Point(6, 9);
            this.lblUpdate.Name = "lblUpdate";
            this.lblUpdate.Size = new System.Drawing.Size(122, 19);
            this.lblUpdate.TabIndex = 2;
            this.lblUpdate.Text = "Spam Update:";
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.Green;
            this.btnStart.Font = new System.Drawing.Font("Footlight MT Light", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnStart.ForeColor = System.Drawing.Color.Black;
            this.btnStart.Location = new System.Drawing.Point(245, 101);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(94, 29);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start Spam";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.BackColor = System.Drawing.Color.Red;
            this.btnStop.Font = new System.Drawing.Font("Footlight MT Light", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnStop.ForeColor = System.Drawing.Color.White;
            this.btnStop.Location = new System.Drawing.Point(245, 128);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(94, 29);
            this.btnStop.TabIndex = 0;
            this.btnStop.Text = "Stop Spam";
            this.btnStop.UseVisualStyleBackColor = false;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // PanelBefore
            // 
            this.PanelBefore.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PanelBefore.BackgroundImage")));
            this.PanelBefore.Controls.Add(this.btnFirstStart);
            this.PanelBefore.Controls.Add(this.lblWelcome);
            this.PanelBefore.Font = new System.Drawing.Font("Footlight MT Light", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PanelBefore.Location = new System.Drawing.Point(3, 3);
            this.PanelBefore.Name = "PanelBefore";
            this.PanelBefore.Size = new System.Drawing.Size(387, 272);
            this.PanelBefore.TabIndex = 2;
            // 
            // btnFirstStart
            // 
            this.btnFirstStart.BackColor = System.Drawing.Color.Maroon;
            this.btnFirstStart.Font = new System.Drawing.Font("Footlight MT Light", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnFirstStart.ForeColor = System.Drawing.Color.White;
            this.btnFirstStart.Location = new System.Drawing.Point(61, 137);
            this.btnFirstStart.Name = "btnFirstStart";
            this.btnFirstStart.Size = new System.Drawing.Size(216, 53);
            this.btnFirstStart.TabIndex = 7;
            this.btnFirstStart.Text = "Start";
            this.btnFirstStart.UseVisualStyleBackColor = false;
            this.btnFirstStart.Click += new System.EventHandler(this.btnFirstStart_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.Font = new System.Drawing.Font("Footlight MT Light", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblWelcome.ForeColor = System.Drawing.Color.White;
            this.lblWelcome.Location = new System.Drawing.Point(6, 18);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(107, 19);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "lblWelcome";
            // 
            // tmrSpam
            // 
            this.tmrSpam.Tick += new System.EventHandler(this.tmrSpam_Tick);
            // 
            // tmrUpdate
            // 
            this.tmrUpdate.Tick += new System.EventHandler(this.tmrUpdate_Tick);
            // 
            // tmrCountdown
            // 
            this.tmrCountdown.Interval = 1000;
            this.tmrCountdown.Tick += new System.EventHandler(this.tmrCountdown_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 240);
            this.Controls.Add(this.PanelBefore);
            this.Controls.Add(this.PanelAfter);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Spam Bot-ofek#6143";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.PanelAfter.ResumeLayout(false);
            this.PanelAfter.PerformLayout();
            this.PanelBefore.ResumeLayout(false);
            this.PanelBefore.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelAfter;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox tbTEXT;
        private System.Windows.Forms.TextBox tbMS;
        private System.Windows.Forms.Label lblMs;
        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.Label lblUpdate;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Panel PanelBefore;
        private System.Windows.Forms.Button btnFirstStart;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Timer tmrSpam;
        private System.Windows.Forms.Timer tmrUpdate;
        private System.Windows.Forms.Label lblTimeReamining;
        private System.Windows.Forms.Timer tmrCountdown;
    }
}

